# app/routers/__init__.py
from . import world, player, settlement, trader, area, animal, item, equipment, task