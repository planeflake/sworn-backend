Allow tasks to become more serious if not completed.

Add seasonal tasks/events

Determine traders cart type to determine repair materails needed
